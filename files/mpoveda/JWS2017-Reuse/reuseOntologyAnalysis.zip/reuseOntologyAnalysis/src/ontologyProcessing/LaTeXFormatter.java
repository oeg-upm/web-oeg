/*
       Copyright 2016 Mariano Fernández-López 

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
 */
package ontologyProcessing;

import java.util.Set;

/**
 * This class is used to generate a LaTex file to present the relevant information about the process of loading of ontologies. See the file analisis_ontologias.pdf to know in detail which is such an information.
 * @author mariano
 */
public class LaTeXFormatter {

    /**
     * This is the method in charge of generating the information in LaTeX format.
     * @param setOfResults the set of ontologies that have been tried to be loaded.
     * @param totalDiagnosis the exceptions that have been arisen.
     * @return a string in LaTeX format that can be saved as it is.
     */
    public static String formatter(Set<OntologyAnalysisResult> setOfResults, TotalDiagnosis totalDiagnosis) {
        StringBuilder sb = new StringBuilder();
        sb.append("\\section{Frequencies of exceptions during the loading of ontologies}\n\n");
        sb.append(setOfResults.size() + " ontologies have been tried to be loaded. "
                + "Below, the absolute frequency of the different exceptions loading ontologies is displayed:");
        sb.append("\\begin{enumerate}\n"
                + "\t\\item Number of ontologies with timeout expiration during "
                + "their loading (after " + OntologyDiagnosis.loadingOntologyTimeout + " seconds) "
                + " without arising any other exception: "
                + totalDiagnosis.getQuantityOfOntologicasConVencimientoDeTimeout() + "\n"
                + "\t\\item Number of ontologies with \\texttt{UnparsableOntologyException}: "
                + totalDiagnosis.getQuantityOfUnparsableOntologyException() + "\n"
                + "\t\\item Number of ontologies with \\texttt{OWLOntologyCreationIOException}: "
                + totalDiagnosis.getQuantityOfOWLOntologyCreationIOException() + "\n"
                + "\t\\item Number of ontologies with \\texttt{UnloadableImportException}: "
                + totalDiagnosis.getQuantityOfUnloadableImportException() + "\n"
                + "\t\\item Number of ontologies with \\texttt{OWLOntologyAlreadyExistsException}: "
                + totalDiagnosis.getQuantityOfOWLOntologyAlreadyExistsException() + "\n"
                + "\t\\item Number of ontologies with \\texttt{OWLOntologyCreationException}: "
                + totalDiagnosis.getQuantityOfOWLOntologyCreationException() + "\n"
                + "\t\\item Number of ontologies with just \\texttt{Exception}: "
                + totalDiagnosis.getQuantityOfException() + "\n"
                + "\\end{enumerate}\n");
        int ontologiasConMetricas = totalDiagnosis.getQuantityOfOntologiasQueSeHanIntentadoCargar()
                - totalDiagnosis.obtainOntologiesWithProblemsToBeLoaded();
        sb.append("For the " + ontologiasConMetricas
                + " ontologies that have been finally loaded, metrics have been provided. "
                + "Additionally, a file in R format with these metrics have been generated.");
        sb.append("\\section{Metrics and failures of the particular ontologies}\n\n");
        setOfResults.forEach(resultado -> {
            sb.append(datosOntologiaFormateados(resultado));
        });

        return sb.toString();
    }

    private static String datosOntologiaFormateados(OntologyAnalysisResult resultado) {
        if (!resultado.getDiagnosis().isUniqueOntology()) {
            return "";
        }
        String contenidoSeccion;
        if (resultado.isIncludeInStadistics()) {
            contenidoSeccion = informacionOntologiaConMetricas(resultado);
        } else {
            contenidoSeccion = informacionOntologiaConErrores(resultado);
        }

        return "\\subsection{" + resultado.getOntologyName() + "}\n\n"
                + contenidoSeccion;
    }

    private static String informacionOntologiaConMetricas(OntologyAnalysisResult resultado) {
        return anotaciones(resultado)
                + metricas(resultado)
                + terminosImportados(resultado)
                + terminosNiDeclaradosNiImportados(resultado);
    }

    private static String metricas(OntologyAnalysisResult resultado) {
        return "\\subsubsection{Metrics}\n\n"
                + "\\begin{enumerate}\n"
                + "\t\\item Number of classes: " + resultado.getNumberOfClasses() + "\n"
                + "\t\\item Number of object properties: " + resultado.getNumberOfObjectProperties() + "\n"
                + "\t\\item Number of datatype properties: " + resultado.getNumberOfDatatypeProperties() + "\n"
                + "\t\\item Total number of terms: " + resultado.obtainTheTotalNumberOfTerms() + "\n"
                + "\t\\item Number of classes from imported ontologies: " + resultado.getNumberOfClassesFromImportedOntologies() + "\n"
                + "\t\\item Number of object properties from imported ontologies: " + resultado.getNumberOfObjectPropertiesFromImportedOntologies() + "\n"
                + "\t\\item Number of datatype properties from imported ontologies: " + resultado.getNumberOfDatatypePropertiesFromImportedOntologies() + "\n"
                + "\t\\item Number of classes neither declared nor comming from imported ontology: " + resultado.getNumberOfClassesNeitherDeclaredNorFromImportedOntologies() + "\n"
                + "\t\\item Number of object properties neither declared  nor comming from imported ontology: " + resultado.getNumberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies() + "\n"
                + "\t\\item Number of datatype properties neither declared  nor comming from imported ontology: " + resultado.getNumberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies() + "\n"
                + "\\end{enumerate}\n\n";
    }

    private static String informacionOntologiaConErrores(OntologyAnalysisResult resultado) {
        OntologyDiagnosis diagnostico = resultado.getDiagnosis();
        StringBuilder sb = new StringBuilder("\\subsubsection{Failures}\n\n");
        sb.append("\\begin{itemize}\n");
        if (!diagnostico.isCorrectImportOfOntologies()) {
            sb.append("\t\\item The following import sentence \\url{").
                    append(resultado.getDiagnosis().getImportedOntologyThatHasNotBeenAbleToBeLoaded()).
                    append("} has failed.\n\n");
        }
        if (!diagnostico.isCorrectParse()) {
            sb.append("\t\\item An \\emph{UnparsableOntologyException} has been arisen.\n\n");
        }
        if (!diagnostico.isCorrectCreationOfOntology()) {
            sb.append("\t\\item " + resultado.getDiagnosis().getException().toString() + ".\n\n");
        }
        if (!diagnostico.isUniqueOntology()) {
            sb.append("\t\\item The ontology already exists.\n\n");
        }
        if (!diagnostico.isOntologyLoadingInAReasonableTime()) {
            sb.append("\t\\item Timeout loading the ontology (").
                    append(OntologyDiagnosis.loadingOntologyTimeout).append(" seconds).\n\n");
        }
        if (!diagnostico.isOntologyWithoutGenericException()) {
            sb.append("\t\\item An exception has arisen during the processing of this ontology.\n\n");
        }
        sb.append("\\end{itemize}\n");
        
        return sb.toString();
    }

    private static String anotaciones(OntologyAnalysisResult resultado) {
        if (resultado.getOntologyAnnotations().isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder("\\subsubsection{Annotations}\n\n");
        sb.append("\\begin{lstlisting}\n");
        resultado.getOntologyAnnotations().
                forEach(anotacion
                        -> sb.append("\t\t").append(anotacion.getProperty()).append(": ").
                        append(anotacion.getValue()).
                        append("\n"));
        sb.append("\\end{lstlisting}\n");

        return sb.toString().
                replaceAll("á", "\\\\'a").replaceAll("é", "\\\\'e").
                replaceAll("í", "\\\\'i").replaceAll("ó", "\\\\'o").
                replaceAll("ú", "\\\\'u").
                replaceAll("à", "\\\\`a").
                replaceAll("è", "\\\\`e").
                replaceAll("ù", "\\\\`u").
                replaceAll("â", "\\\\^a").replaceAll("ê", "\\\\^e").
                replaceAll("î", "\\\\^i").replaceAll("ô", "\\\\^o").
                replaceAll("û", "\\\\^u").replaceAll("ç", "\\\\c").
                replaceAll("Á", "\\\\'A").replaceAll("É", "\\\\'E").
                replaceAll("Í", "\\\\'I").replaceAll("Ó", "\\\\'O").
                replaceAll("Ú", "\\\\'U").
                replaceAll("À", "\\\\`A").
                replaceAll("È", "\\\\`E").
                replaceAll("À", "\\\\^A").replaceAll("Ê", "\\\\^E").
                replaceAll("Î", "\\\\^I").replaceAll("Ô", "\\\\^O").
                replaceAll("Û", "\\\\\"u").replaceAll("ö", "\\\\\"o").
                replaceAll("C", "\\\\C").
                replaceAll("ñ", "\\\\'n").replaceAll("Ñ", "\\\\'N").
                replaceAll("«", "<<").
                replaceAll("»", ">>").
                replaceAll("’", "'").
                replaceAll("~", "\\\\~").
                replaceAll("ã", "\\\\~a"). //"

                replaceAll("©", "\\textcopyright");
    }

    private static String terminosImportados(OntologyAnalysisResult resultado) {
        if (resultado.getImportedTerms().isEmpty()) {
            return "";
        }

        StringBuilder terminosFormateados = new StringBuilder("\\subsubsection{Terms from imported ontologies}\n\n");
        terminosFormateados.append("\\begin{itemize}\n");
        resultado.getImportedTerms().forEach(termino -> {
            terminosFormateados.append("\t\\item \\url{").append(termino).append("}\n");
        }
        );
        terminosFormateados.append("\\end{itemize}\n\n");

        return terminosFormateados.toString();
    }

    private static String terminosNiDeclaradosNiImportados(OntologyAnalysisResult resultado) {
        if (resultado.getNeitherDeclaredNorImportedTerms().isEmpty()) {
            return "";
        }

        StringBuilder terminosFormateados = new StringBuilder("\\subsubsection{Terms that are neither declared  nor comming from imported ontologies}\n\n");
        terminosFormateados.append("\\begin{itemize}\n");
        resultado.getNeitherDeclaredNorImportedTerms().forEach(termino -> {
            terminosFormateados.append("\t\\item \\url{").append(termino).append("}\n");
        }
        );
        terminosFormateados.append("\\end{itemize}\n\n");

        return terminosFormateados.toString();
    }

}
