/*
       Copyright 2016 Mariano Fernández-López 

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
 */
package ontologyProcessing;

/**
 * Every objetct of this class contains the following information:
 <ul>
  <li>the waiting timeout after which it is considered that the ontology has not been able to be loaded (it is predefined to 120 s);</li>
  <li>if the ontologies are correctly imported;</li>
  <li>If the ontology has been correctly parsed;</li>
  <li>If the ontology has been correctly created after its loading;</li>
  <li>The error message, if any, when creating the ontology;</li>
  <li>If the ontology has been able to be loadad in a reasonable time (120 s);</li>
  <li>If the ontology is unique, that is, it is not repeated;</li>
  <li>If the ontology has been created without a generic exception;</li>
  <li>If the ontology has been created correctly when having loaded;</li>
  <li>What imported ontology, if there is any, has not been able to be loaded; and</li>
  <li>What exception, if any, has not been arisen.</li>
</ul> 
 * @author mariano
 */
public class OntologyDiagnosis {

    public static long loadingOntologyTimeout = 120;  //120 segundos. Para realizar pruebas rápidas, se puede poner 5
    private boolean correctImportOfOntologies = true;
    private boolean correctParse = true;
    private boolean correctCreationOfOntology = true;
    private String errerMessageInOntologyCreation;
    private boolean ontologyLoadingInAReasonableTime = true;
    private boolean UniqueOntology = true; // Es decir, no repetida
    private boolean ontologyWithoutGenericException = true;
    private boolean ontologyCorrectlyCreated = true;
    String importedOntologyThatHasNotBeenAbleToBeLoaded;
    private Exception exception;

    /**
     * The ontology is considered correct if, and only if, its imported ontologies are correctly loaded, it is correctly parsed, it is correctly created, it is unique (i.e., it is not repeated), and no exception has not been arisen when being loaded.
     * @return the conjunction of the aforementioned conditions.
     */
    public boolean isCorrectOntology() {
        return isOntologyLoadingInAReasonableTime()
                && isCorrectImportOfOntologies()
                && isCorrectParse()
                && isCorrectCreationOfOntology()
                && isUniqueOntology()
                && isOntologyWithoutGenericException();
    }

    /**
     * It returns the imported ontology that tas not been able to be loaded, if any;
     * or the empty string otherwise.
     * @return the imported ontology, if any, that has not been able to be loaded. 
     */
    public String getImportedOntologyThatHasNotBeenAbleToBeLoaded() {
        return importedOntologyThatHasNotBeenAbleToBeLoaded;
    }

    /**
     * It sets the imported ontology that has not been able to be loaded.
     * @param importedOntologyThatHasNotBeenAbleToBeLoaded the imported ontology, if any, that has not been able to be loaded.
 importedOntologyThatHasNotBeenAbleToBeLoaded to set
     */
    public void setImportedOntologyThatHasNotBeenAbleToBeLoaded(String importedOntologyThatHasNotBeenAbleToBeLoaded) {
        this.importedOntologyThatHasNotBeenAbleToBeLoaded = importedOntologyThatHasNotBeenAbleToBeLoaded;
    }

    /**
     * It returns true if the ontologies have been correctly imported.
     * @return if the ontologies have been correctly imported. 
     */
    public boolean isCorrectImportOfOntologies() {
        return correctImportOfOntologies;
    }

    /**
     * It sets if the ontologies have been correctly imported.
     * @param correctImportOfOntologies if the ontologies have been correctly imported.
     */
    public void setCorrectImportOfOntologies(boolean correctImportOfOntologies) {
        this.correctImportOfOntologies = correctImportOfOntologies;
    }

    /**
     * It returns true if the ontology has been correctly parsed. 
     * @return if the ontology has been correctly parsed. 
     */
    public boolean isCorrectParse() {
        return correctParse;
    }

    /**
     *  It sets if the ontology has been correctly parsed. 
     * @param correctParse if the ontology has been correctly parsed.
     */
    public void setCorrectParse(boolean correctParse) {
        this.correctParse = correctParse;
    }

    /**
     * It returns true if the ontology has been able to be loaded in a reasonable time. 
     * @return if the ontology has been able to be loadad in a reasonable time.
     */
    public boolean isOntologyLoadingInAReasonableTime() {
        return ontologyLoadingInAReasonableTime;
    }

    /**
     * It sets if the ontology has been able to be loaded in a reasonable time. 
     * @param ontologyLoadingInAReasonableTime if the ontology has been able to be loadad in a reasonable time.
     */
    public void setOntologyLoadingInAReasonableTime(boolean ontologyLoadingInAReasonableTime) {
        this.ontologyLoadingInAReasonableTime = ontologyLoadingInAReasonableTime;
    }

    /**
     * It returns true if the ontology is unique.
     * @return if the ontology is unique. 
     */
    public boolean isUniqueOntology() {
        return UniqueOntology;
    }

    /**
     * It sets if the ontology is unique. 
     * @param UniqueOntology if the ontology is unique.
     */
    public void setUniqueOntology(boolean UniqueOntology) {
        this.UniqueOntology = UniqueOntology;
    }

    /**
     * It returns true if the ontology has been loaded without arising any generic exception. 
     * @return ontologyWithoutGenericException if the ontology has been created without a generic exception
     */
    public boolean isOntologyWithoutGenericException() {
        return ontologyWithoutGenericException;
    }

    /**
     * It sets if the ontology has been loaded withoug arising any generic exception. 
     * @param ontologyWithoutGenericException if the ontology has been created without a generic exception
     */
    public void setOntologyWithoutGenericException(boolean ontologyWithoutGenericException) {
        this.ontologyWithoutGenericException = ontologyWithoutGenericException;
    }

    /**
     * It returns true if the ontology has been created correctly when having loaded.
     * @return if the ontology has been created correctly when having loaded
     */
    public boolean isOntologyCorrectlyCreated() {
        return ontologyCorrectlyCreated;
    }

    /**
     * It sets if the ontology has been created correctly when having loaded.
     * @param ontologyCorrectlyCreated if the ontology has been created correctly when having loaded
     */
    public void setOntologyCorrectlyCreated(boolean ontologyCorrectlyCreated) {
        this.ontologyCorrectlyCreated = ontologyCorrectlyCreated;
    }

    /**
     * It returns the error message, if any, when creating the ontology; or the
     * empty string otherwise.
     * @return the error message, if any, when creating the ontology
     */
    public String getErrerMessageInOntologyCreation() {
        return errerMessageInOntologyCreation;
    }

    /**
     * It sets an error message when creating the ontology
     * @param errerMessageInOntologyCreation the error message, if any, when creating the ontology
     */
    public void setErrerMessageInOntologyCreation(String errerMessageInOntologyCreation) {
        this.errerMessageInOntologyCreation = errerMessageInOntologyCreation;
    }

    /**
     * It returns true if the ontology has been created correctly when having loaded.
     * @return if the ontology has been created correctly when having loaded
     */
    public boolean isCorrectCreationOfOntology() {
        return correctCreationOfOntology;
    }

    /**
     * It sets if the ontology has been created correctly when having loaded.
     * @param correctCreationOfOntology if the ontology has been created correctly when having loaded.
     */
    public void setCorrectCreationOfOntology(boolean correctCreationOfOntology) {
        this.correctCreationOfOntology = correctCreationOfOntology;
    }

    /**
     * It returns true if some exception has been arisen during the ontology loading. 
     * @return what exception, if any, has not been arisen.
     */
    public Exception getException() {
        return exception;
    }

    /**
     * It sets an exception that has been arisen during the ontology loading.
     * @param exception what exception, if any, has not been arisen.
     */
    public void setException(Exception exception) {
        this.exception = exception;
    }

}
