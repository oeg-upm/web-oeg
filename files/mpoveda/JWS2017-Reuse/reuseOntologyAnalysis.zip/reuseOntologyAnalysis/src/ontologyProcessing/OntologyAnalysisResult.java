/*
       Copyright 2016 Mariano Fernández-López 

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
 */
package ontologyProcessing;

import java.util.Set;
import java.util.TreeSet;
import org.semanticweb.owlapi.model.OWLAnnotation;

/**
 * This ontology is used to obtain the reuse date of an ontology: number of clases,
 * number of object properties, number of datatype properties, number of declared
 * classes, number of imported clases, number of classes that are neither declared
 * nor imported, number of declared object properties, etc.
 * @author mariano
 */
public class OntologyAnalysisResult {
    private String ontologyUri;
    private String ontologyName;
    private int NumberOfClasses;
    private int numberOfObjectProperties;
    private int numberOfDatatypeProperties;
    private int numberOfDeclaredClasses;
    private int numberOfClassesFromImportedOntologies;
    private int numberOfDeclaredObjectProperties;
    private int numberOfObjectPropertiesFromImportedOntologies;
    private int numberOfDeclaredDatatypeProperties;
    private int numberOfDatatypePropertiesFromImportedOntologies;
    private int numberOfClassesNeitherDeclaredNorFromImportedOntologies;
    private int numberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies;
    private int numberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies;
    private final Set<String> declaredTerms = new TreeSet();
    private final Set<String> importedTerms = new TreeSet<>();
    private final Set<String> neitherDeclaredNorImportedTerms = new TreeSet<>();
    private final OntologyDiagnosis diagnosis = new OntologyDiagnosis();
    private Set<OWLAnnotation> ontologyAnnotations = new TreeSet<>();
    
    /**
     * It obtains the sum of classes, object properties and datatype properties.
     * @return the sum of classes, object properties and datatype properties.
     */
    public int obtainTheTotalNumberOfTerms()
    {
        return this.NumberOfClasses + this.numberOfObjectProperties + this.numberOfDatatypeProperties;
    }
    
    /**
     * Obtains the number of not declared classes.
     * @return the number of not declared classes.
     */
    public int obtainTheTotalNumberOfNotDeclaredClasses()
    {
        return this.NumberOfClasses - this.numberOfDeclaredClasses;
    }
    
    /**
     * It returns the number of classes of the ontology. 
     * @return the number of classes of the ontology. 
     */
    public int getNumberOfClasses() {
        return NumberOfClasses;
    }

    /**
     * It sets the number of classes of the ontology. 
     * @param NumberOfClasses the NumberOfClasses to set
     */
    public void setNumberOfClasses(int NumberOfClasses) {
        this.NumberOfClasses = NumberOfClasses;
    }

    /**
     * It returns number of object properties of the ontology. 
     * @return the number of object properties of the ontology.
     */
    public int getNumberOfObjectProperties() {
        return numberOfObjectProperties;
    }

    /**
     * It sets the number of object properties of the ontology. 
     * @param numberOfObjectProperties the number of object properties of the ontology.
     */
    public void setNumberOfObjectProperties(int numberOfObjectProperties) {
        this.numberOfObjectProperties = numberOfObjectProperties;
    }

    /**
     * It returns the number of datatype properties of the ontology. 
     * @return the number of datatype properties of the ontology. 
     */
    public int getNumberOfDatatypeProperties() {
        return numberOfDatatypeProperties;
    }

    /**
     * It sets the number of datatype properties of the ontology. 
     * @param numberOfDatatypeProperties the number of datatype properties of the ontology. 
     */
    public void setNumberOfDatatypeProperties(int numberOfDatatypeProperties) {
        this.numberOfDatatypeProperties = numberOfDatatypeProperties;
    }

    /**
     * It returns the ontology URI. 
     * @return the ontology URI. 
     */
    public String getOntologyUri() {
        return ontologyUri;
    }

    /**
     * It sets the ontology URI. 
     * @param ontologyUri the ontology URI. 
     */
    public void setOntologyUri(String ontologyUri) {
        this.ontologyUri = ontologyUri;
    }

    /**
     * It returns the number of declared classes. 
     * @return the numberOfDeclaredClasses
     */
    public int getNumberOfDeclaredClasses() {
        return numberOfDeclaredClasses;
    }

    /**
     * It sets the number of declared classes. 
     * @param numberOfDeclaredClasses the number of declared classes. 
     */
    public void setNumberOfDeclaredClasses(int numberOfDeclaredClasses) {
        this.numberOfDeclaredClasses = numberOfDeclaredClasses;
    }

    /**
     * It returns the ontology name. 
     * @return the ontology name. 
     */
    public String getOntologyName() {
        return ontologyName;
    }

    /**
     * It sets the ontology name. 
     * @param ontologyName the ontology name. 
     */
    public void setOntologyName(String ontologyName) {
        this.ontologyName = ontologyName;
    }

    /**
     * It returns true if and only if the ontology is correct and, therefore,
     * its statistics will be included. 
     * @return the incluirEnEstadisticas
     */
    public boolean isIncludeInStadistics() {
        return diagnosis.isCorrectOntology();
    }

    /**
     * It returns the number of imported classes. 
     * @return the number of imported classes. 
     */
    public int getNumberOfClassesFromImportedOntologies() {
        return numberOfClassesFromImportedOntologies;
    }

    /**
     * It sets the number of imported classes. 
     * @param numberOfClassesFromImportedOntologies the number of imported classes. 
     */
    public void setNumberOfClassesFromImportedOntologies(int numberOfClassesFromImportedOntologies) {
        this.numberOfClassesFromImportedOntologies = numberOfClassesFromImportedOntologies;
    }

    /**
     * The number of declared object properties.
     * @return the number of declared object properties. 
     */
    public int getNumberOfDeclaredObjectProperties() {
        return numberOfDeclaredObjectProperties;
    }

    /**
     * It sets the number of declared object properties. 
     * @param numberOfDeclaredObjectProperties the number of declared object properties. 
     */
    public void setNumberOfDeclaredObjectProperties(int numberOfDeclaredObjectProperties) {
        this.numberOfDeclaredObjectProperties = numberOfDeclaredObjectProperties;
    }

    /**
     * It returns the number of imported object properties. 
     * @return the number of imported object properties. 
     */
    public int getNumberOfObjectPropertiesFromImportedOntologies() {
        return numberOfObjectPropertiesFromImportedOntologies;
    }

    /**
     * It sets the number of imported object properties. 
     * @param numberOfObjectPropertiesFromImportedOntologies the number of imported object properties. 
     */
    public void setNumberOfObjectPropertiesFromImportedOntologies(int numberOfObjectPropertiesFromImportedOntologies) {
        this.numberOfObjectPropertiesFromImportedOntologies = numberOfObjectPropertiesFromImportedOntologies;
    }

    /**
     * It returns the number of declared datatype properties.
     * @return the number of datatype properties. 
     */
    public int getNumberOfDeclaredDatatypeProperties() {
        return numberOfDeclaredDatatypeProperties;
    }

    /**
     * It sets the number of declared datatype properties. 
     * @param numberOfDeclaredDatatypeProperties the number of declared datatype properties. 
     */
    public void setNumberOfDeclaredDatatypeProperties(int numberOfDeclaredDatatypeProperties) {
        this.numberOfDeclaredDatatypeProperties = numberOfDeclaredDatatypeProperties;
    }

    /**
     * It returns the number of imported datatype properties. 
     * @return the number of imported datatype properties. 
     */
    public int getNumberOfDatatypePropertiesFromImportedOntologies() {
        return numberOfDatatypePropertiesFromImportedOntologies;
    }

    /**
     * It sets the number of imported datatype properties.
     * @param numberOfDatatypePropertiesFromImportedOntologies the imported datatype properties.
     */
    public void setNumberOfDatatypePropertiesFromImportedOntologies(int numberOfDatatypePropertiesFromImportedOntologies) {
        this.numberOfDatatypePropertiesFromImportedOntologies = numberOfDatatypePropertiesFromImportedOntologies;
    }

    /**
     * It returns the number of classes that have not been neither declared nor imported. 
     * @return the number of classes that have not been neither declared nor imported. 
     */
    public int getNumberOfClassesNeitherDeclaredNorFromImportedOntologies() {
        return numberOfClassesNeitherDeclaredNorFromImportedOntologies;
    }

    /**
     * It sets the number of classes that have not been neither declared nor imported. 
     * @param numberOfClassesNeitherDeclaredNorFromImportedOntologies the number of classes that have not been neither declared nor imported.
     */
    public void setNumberOfClassesNeitherDeclaredNorFromImportedOntologies(int numberOfClassesNeitherDeclaredNorFromImportedOntologies) {
        this.numberOfClassesNeitherDeclaredNorFromImportedOntologies = numberOfClassesNeitherDeclaredNorFromImportedOntologies;
    }

    /**
     * It returns the number of object properties that have not been neither declared nor imported.
     * @return the the number of object properties that have not been neither declared nor imported. 
     */
    public int getNumberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies() {
        return numberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies;
    }

    /**
     * It sets the number of object properties that have not been neither declared nor imported. 
     * @param numberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies the number of object properties that have not been neither declared nor imported.
     */
    public void setNumberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies(int numberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies) {
        this.numberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies = numberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies;
    }

    /**
     * It returns the number of datatype properties that have not been neither declared nor imported. 
     * @return the number of datatype properties that have not been neither declared nor imported.
     */
    public int getNumberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies() {
        return numberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies;
    }

    /**
     * It sets the number of datatype properties that have not been neither declared nor imported.
     * @param numberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies the number of datatype properties that have not been neither declared nor imported.
     */
    public void setNumberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies(int numberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies) {
        this.numberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies = numberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies;
    }

    /**
     * It adds a term declared in the ontology.
     */
    public void addDeclaredTerm(String termino)
    {
        this.getDeclaredTerms().add(termino);
    }
   
    /**
     * It adds an imported term.
     */ 
    public void addImportedTerm(String termino)
    {
        this.getImportedTerms().add(termino);
    }

    /**
     * It returns a set with the imported terms. 
     * @return the set with the imported terms. 
     */
    public Set<String> getImportedTerms() {
        return importedTerms;
    }

    /**
     * It adds a term that has been neither declared nor imported.
     */
    public void addNeitherDeclaredNorImportedTerm(String termino)
    {
        this.getNeitherDeclaredNorImportedTerms().add(termino);
    }
    
    /**
     * It returns the ontology diagnosis. 
     * @return the diagnosis
     */
    public OntologyDiagnosis getDiagnosis() {
        return diagnosis;
    }

    /**
     * It returns the set of neither declared nor imported. 
     * @return the set of neither declared nor imported terms. 
     */
    public Set<String> getNeitherDeclaredNorImportedTerms() {
        return neitherDeclaredNorImportedTerms;
    }

    /**
     * It returns the set of the ontology annotations. 
     * @return the set of ontology annotations. 
     */
    public Set<OWLAnnotation> getOntologyAnnotations() {
        return ontologyAnnotations;
    }

    /**
     * It sets the ontology annotations. 
     * @param ontologyAnnotations the ontology annotations. 
     */
    public void setOntologyAnnotations(Set<OWLAnnotation> ontologyAnnotations) {
        this.ontologyAnnotations = ontologyAnnotations;
    }

    /**
     * It returns the set of declared terms. 
     * @return the set of declared terms. 
     */
    public Set<String> getDeclaredTerms() {
        return declaredTerms;
    }
}
