/**
 * Package that contains the program logic.
 */
package ontologyProcessing;
