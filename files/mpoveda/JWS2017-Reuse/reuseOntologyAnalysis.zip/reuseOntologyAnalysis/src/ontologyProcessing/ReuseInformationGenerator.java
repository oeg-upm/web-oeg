/*
       Copyright 2016 Mariano Fernández-López 

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
 */
package ontologyProcessing;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import myutilities.MyUtilities;
import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.io.OWLOntologyCreationIOException;
import org.semanticweb.owlapi.io.UnparsableOntologyException;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLNamedObject;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyAlreadyExistsException;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.UnloadableImportException;
import application.Main;

/**
 * An object of this class is in charge of coorditating the generation of
 * the reuse information.
 * @author mariano
 */
public class ReuseInformationGenerator {

    private final Map<String, OntologyInformation> mapUriNs;
    //Las siguientes variables son globales para que sean visibles desde el
    //método call de la clase privada Tarea.
    //private final OWLOntologyManager manager;
    private final Set<String> nombresOntologiasMalContabilizadas = new TreeSet<>();
    private final String rutaFicheroLogsErroresDeProgramacion = "logs_errores_programacion.txt";
    private TotalDiagnosis diagnosticoTotal = new TotalDiagnosis();

    /**
     * Builds an a reuse information generator from a spread sheet with the
     * information with the LOV ontologies.
     */
    public ReuseInformationGenerator() {
        //tablaURINS = importUriNsTable("./ns_vs_uri_prueba.ods");
        //tablaURINS = importUriNsTable("./ns_vs_uri_prueba_timeout.ods");
        //tablaURINS = importUriNsTable("./ns_vs_uri.ods");
        mapUriNs = importUriNsTable("./Ns_vs_Uri_congelado.ods");
        File file = new File("logs_errores_programacion.txt");
        file.delete();
    }

    /**
     * It obtains the information of the LOV ontologies.
     */
    public void obtainInformationOfOntologies() {
        Set<OntologyAnalysisResult> cjtoResultados = new HashSet<>();
        mapUriNs.forEach((nombreOntologia, descOntologia) -> {
            System.out.println("\n\nPROCESSING URI: " + descOntologia.getUri());
            System.out.println("------------------------------------------\n");
            OntologyAnalysisResult res;
            res = obtainOntologyInformationFromUri(nombreOntologia, descOntologia.getUri());
            cjtoResultados.add(res);
        });
        String estadisticasParaR = RFormatter.formatter(cjtoResultados.stream().
                filter(resultado -> resultado.isIncludeInStadistics()).
                collect(Collectors.toSet()));
        MyUtilities.writeInFile("./estadisticas/datos_reuse.dat", estadisticasParaR);
        System.out.println(estadisticasParaR);
        System.out.println();
        String contenidoLaTeX = LaTeXFormatter.formatter(cjtoResultados, this.diagnosticoTotal);
        MyUtilities.writeInFile("./analisis_ontologias/content.tex", contenidoLaTeX);
        System.out.println(contenidoLaTeX);
        if (!this.nombresOntologiasMalContabilizadas.isEmpty()) {
            this.generateLogOfProgrammingErrors();
        }
        System.exit(0);
    }

    private OntologyAnalysisResult obtainOntologyInformationFromUri(String nombreOntologia, String uri) {
        OntologyAnalysisResult res = new OntologyAnalysisResult();
        try {
            res.setOntologyName(nombreOntologia);
            res.setOntologyUri(uri);
            //OWLOntology modeloOWL = manager.createOntology();
            //IRI iri = IRI.create(uri);
            OWLOntology modeloOWL = loadOntology(res, uri);
            if (!res.getDiagnosis().isCorrectOntology()) {
                return res;
            }
            obtainAnnotationsOfTheOntology(modeloOWL, res);
            addMetrics(modeloOWL, nombreOntologia, res);
            System.out.println("The processing of " + uri + " has been carried out!!");
        } catch (UnloadableImportException ex) {
            res.getDiagnosis().setCorrectImportOfOntologies(false);
            System.err.println("En " + nombreOntologia + " la siguiente ontología " + ex.getImportsDeclaration() + " no se ha podido cargar");
            res.getDiagnosis().setImportedOntologyThatHasNotBeenAbleToBeLoaded(ex.getImportsDeclaration().toString());
        }

        return res;
    }

    private void obtainAnnotationsOfTheOntology(OWLOntology modeloOWL, OntologyAnalysisResult res) {
        res.setOntologyAnnotations(modeloOWL.getAnnotations());
//        Set<OWLAnnotation> lAnotaciones = modeloOWL.getAnnotations();
    }

    private void dealWithExceptions(String uri, Exception ex, OntologyAnalysisResult res) {
        res.getDiagnosis().setException(ex);
        //Si también ha habido un timeout, se decrementa el contador de ontologías con
        //timeout para que no se cuenten varias veces.
        if (!res.getDiagnosis().isOntologyLoadingInAReasonableTime()) {
            diagnosticoTotal.setQuantityOfOntologicasConVencimientoDeTimeout(diagnosticoTotal.getQuantityOfOntologicasConVencimientoDeTimeout() - 1);
        }
        System.err.println("Error en " + uri + " " + ex);
    }

    private void addMetrics(OWLOntology modeloOWL, String nombreOntologia, OntologyAnalysisResult res) {
        //Se dice clasesDeOntologiasImportadas, p.ej., porque hay términos de ontologías importadas
        //sobre los que se restringe su significado en la ontología importada, pero no aparecen en
        //ella en el sujeto de ninguna terna.

        Set<OWLOntology> ontologiasImportadas = modeloOWL.getImports();

        //MÉTRICAS CLASES
        Set<OWLClass> clasesCierre = modeloOWL.getClassesInSignature(true);
        res.setNumberOfClasses(clasesCierre.size());
        Set<OWLClass> clasesDeclaradas = this.obtainSetOfDeclaredClasses(modeloOWL, nombreOntologia);
        clasesDeclaradas.forEach(clase -> res.addDeclaredTerm(clase.getIRI().toString()));
        res.setNumberOfDeclaredClasses(clasesDeclaradas.size());
        Set<OWLClass> clasesDeOntologiasImportadas = new TreeSet<>();
        ontologiasImportadas.
                forEach(ontologiaImportada -> clasesDeOntologiasImportadas.addAll(ontologiaImportada.getClassesInSignature(true)));
        res.setNumberOfClassesFromImportedOntologies(clasesDeOntologiasImportadas.size());
        Set<OWLClass> clasesNDNI = clasesCierre.stream().filter(clase -> !clasesDeOntologiasImportadas.contains(clase) && !clasesDeclaradas.contains(clase)).collect(Collectors.toSet());
        res.setNumberOfClassesNeitherDeclaredNorFromImportedOntologies(clasesNDNI.size());
        clasesNDNI.forEach(clase -> res.addNeitherDeclaredNorImportedTerm(clase.getIRI().toString()));

        //MÉTRICAS OBJECT PROPERTIES
        Set<OWLObjectProperty> opCierre = modeloOWL.getObjectPropertiesInSignature(true);
        res.setNumberOfObjectProperties(opCierre.size());
        Set<OWLObjectProperty> opDeclaradas = this.setOfDeclaredObjectProperties(modeloOWL, nombreOntologia);
        opDeclaradas.forEach(op -> res.addDeclaredTerm(op.getIRI().toString()));
        res.setNumberOfDeclaredObjectProperties(opDeclaradas.size());
        Set<OWLObjectProperty> opDeOntologiasImportadas = new TreeSet<>();
        ontologiasImportadas.
                forEach(ontologiaImportada -> opDeOntologiasImportadas.addAll(ontologiaImportada.getObjectPropertiesInSignature(true)));
        res.setNumberOfObjectPropertiesFromImportedOntologies(opDeOntologiasImportadas.size());
        opDeOntologiasImportadas.forEach(op -> res.addImportedTerm(op.getIRI().toString()));
        Set<OWLObjectProperty> opNDNI = opCierre.stream().filter(op -> !opDeOntologiasImportadas.contains(op) && !opDeclaradas.contains(op)).collect(Collectors.toSet());
        res.setNumberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies(opNDNI.size());
        opNDNI.forEach(op -> res.addNeitherDeclaredNorImportedTerm(op.getIRI().toString()));

        //MÉTRICAS DATATYPE PROPERTIES
        Set<OWLDataProperty> dpCierre = modeloOWL.getDataPropertiesInSignature(true);
        res.setNumberOfDatatypeProperties(dpCierre.size());
        Set<OWLDataProperty> dpDeclaradas = this.setOfDeclaredDataProperties(modeloOWL, nombreOntologia);
        dpDeclaradas.forEach(dp -> res.addDeclaredTerm(dp.getIRI().toString()));
        res.setNumberOfDeclaredDatatypeProperties(dpDeclaradas.size());
        Set<OWLDataProperty> dpDeOntologiasImportadas = new TreeSet<>();
        ontologiasImportadas.
                forEach(ontologiaImportada -> dpDeOntologiasImportadas.addAll(ontologiaImportada.getDataPropertiesInSignature(true)));
        dpDeOntologiasImportadas.forEach(dp -> res.addImportedTerm(dp.getIRI().toString()));
        res.setNumberOfDatatypePropertiesFromImportedOntologies(dpDeOntologiasImportadas.size());
        Set<OWLDataProperty> dpNDNI = dpCierre.stream().filter(dp -> !dpDeOntologiasImportadas.contains(dp) && !dpDeclaradas.contains(dp)).collect(Collectors.toSet());
        res.setNumberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies(dpNDNI.size());
        dpNDNI.forEach(dp -> res.addNeitherDeclaredNorImportedTerm(dp.getIRI().toString()));

        System.out.println("VALIDEZ RESULTADO :" + this.validateResult(res, nombreOntologia));
    }

    private boolean validateResult(OntologyAnalysisResult res, String nombreOntologia) {
        //La validación no podrá dar "verdadero" para importaciones indirectas.
        int sumaNClases = res.getNumberOfDeclaredClasses()
                + res.getNumberOfClassesFromImportedOntologies()
                + res.getNumberOfClassesNeitherDeclaredNorFromImportedOntologies();
        System.out.println("Clases declaradas :" + res.getNumberOfDeclaredClasses());
        System.out.println("Clases de ontologías importadas :" + res.getNumberOfClassesFromImportedOntologies());
        System.out.println("Clases ni declaradas ni importadas :" + res.getNumberOfClassesNeitherDeclaredNorFromImportedOntologies());
        System.out.println("Clases totales (RESULTADO DIRECTO) :" + res.getNumberOfClasses());
        System.out.println("Clases totales (SUMA) :" + sumaNClases);
        boolean contabilidadClasesCorrecta = sumaNClases == res.getNumberOfClasses();

        int sumaNObjectProperties = res.getNumberOfDeclaredObjectProperties()
                + res.getNumberOfObjectPropertiesFromImportedOntologies()
                + res.getNumberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies();
        System.out.println("Object properties declaradas :" + res.getNumberOfDeclaredObjectProperties());
        System.out.println("Object properties importadas :" + res.getNumberOfObjectPropertiesFromImportedOntologies());
        System.out.println("Object properties ni declaradas ni importadas :" + res.getNumberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies());
        System.out.println("Object properties totales (RESULTADO DIRECTO) :" + res.getNumberOfObjectProperties());
        System.out.println("Object properties totales (SUMA) :" + sumaNObjectProperties);
        boolean contabilidadObjectPropertiesCorrecta = sumaNObjectProperties == res.getNumberOfObjectProperties();

        int sumaNDatatypeProperties = res.getNumberOfDeclaredDatatypeProperties()
                + res.getNumberOfDatatypePropertiesFromImportedOntologies()
                + res.getNumberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies();
        System.out.println("Datatype properties declaradas :" + res.getNumberOfDeclaredDatatypeProperties());
        System.out.println("Datatype properties de ontologías importadas :" + res.getNumberOfDatatypePropertiesFromImportedOntologies());
        System.out.println("Datatype properties ni declaradas ni importadas :" + res.getNumberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies());
        System.out.println("Datatype properties totales (RESULTADO DIRECTO) :" + res.getNumberOfDatatypeProperties());
        System.out.println("Datatype properties totales (SUMA) :" + sumaNDatatypeProperties);
        boolean contabilidadDatatypePropertiesCorrecta = sumaNDatatypeProperties == res.getNumberOfDatatypeProperties();

        boolean contabilidadCorrecta = contabilidadClasesCorrecta && contabilidadObjectPropertiesCorrecta && contabilidadDatatypePropertiesCorrecta;
        if (!contabilidadCorrecta) {
            nombresOntologiasMalContabilizadas.add(nombreOntologia);
        }

        return contabilidadCorrecta;
    }

    private void generateLogOfProgrammingErrors() {
        try {
            FileWriter fw = new FileWriter(rutaFicheroLogsErroresDeProgramacion);
            this.nombresOntologiasMalContabilizadas.forEach(nombre -> {
                try {
                    fw.write(nombre);
                } catch (IOException ex) {
                    System.err.println("Error de escritura en el fichero de "
                            + "logs de errores con la ontología " + nombre);
                }
            });
            fw.close();
        } catch (IOException ex) {
            Logger.getLogger(ReuseInformationGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //No vale con utilizar modeloOWL.isDeclared(oe) porque se devolvería true
    //si y sólo si oe es el sujeto de alguna terna.
    private Set<OWLClass> obtainSetOfDeclaredClasses(OWLOntology modeloOWL, String nombreOntologia) {
        Set<OWLClass> cjtoClasesDeclaradas = new HashSet<>();
        modeloOWL.getClassesInSignature().stream().
                filter((oe) -> (isDeclaredEntityInTheOntology(nombreOntologia, oe))).forEach((oe) -> {
                    cjtoClasesDeclaradas.add(oe);
                });

        return cjtoClasesDeclaradas;
    }

    private boolean isDeclaredEntityInTheOntology(String nombreOntologia, OWLNamedObject entidad) {
        OntologyInformation ohc = this.mapUriNs.get(nombreOntologia);
        return entidad.getIRI().toString().contains(ohc.getUri()) || entidad.getIRI().toString().contains(ohc.getNameSpace());
    }

    private Set<OWLObjectProperty> setOfDeclaredObjectProperties(OWLOntology modeloOWL, String nombreOntologia) {
        Set<OWLObjectProperty> cjtoObjectPropertiesDeclaradas = new HashSet<>();
        modeloOWL.getObjectPropertiesInSignature().stream().
                filter((oe) -> (isDeclaredEntityInTheOntology(nombreOntologia, oe))).forEach((oe) -> {
                    cjtoObjectPropertiesDeclaradas.add(oe);
                });

        return cjtoObjectPropertiesDeclaradas;
    }

    private Set<OWLDataProperty> setOfDeclaredDataProperties(OWLOntology modeloOWL, String nombreOntologia) {
        Set<OWLDataProperty> cjtoDataPropertiesDeclaradas = new HashSet<>();
        modeloOWL.getDataPropertiesInSignature().stream().
                filter((oe) -> (isDeclaredEntityInTheOntology(nombreOntologia, oe))).forEach((oe) -> {
                    cjtoDataPropertiesDeclaradas.add(oe);
                });

        return cjtoDataPropertiesDeclaradas;
    }

    private Map<String, OntologyInformation> importUriNsTable(String rutaFicheroIRIs) {
        System.out.println("Importando la tabla NS vs URI");
        Map<String, OntologyInformation> tablaURINSvarLocal = new HashMap<>();
        int filasSeguidasVacias = 0;

        try {
            File file = new File(rutaFicheroIRIs);

            //Crea un objeto para la  hoja de cálculo
            SpreadSheet hoja = SpreadSheet.createFromFile(file);
            //Toma la primera pestaña de la hoja de cálculo
            Sheet pestanna = hoja.getSheet(0);
            int numeroDeFilas = pestanna.getRowCount();

            //Comprueba la columna 1 (la segunda), que es donde está la URI
            for (int i = 0; i < numeroDeFilas && filasSeguidasVacias <= MyUtilities.getLimitOfConsecutiveEmptyRows(); i++) {
                String contenidoCelda1 = pestanna.getCellAt(0, i).getTextValue().trim();
                String contenidoCelda2 = pestanna.getCellAt(1, i).getTextValue().trim();
                String contenidoCelda3 = pestanna.getCellAt(2, i).getTextValue().trim();
                boolean leyendoURI = contenidoCelda2.length() > 0;
                if (!leyendoURI) {
                    filasSeguidasVacias++;
                } else {
                    filasSeguidasVacias = 0;
                }

                if (leyendoURI) {
                    OntologyInformation ohc = new OntologyInformation();
                    ohc.setUri(contenidoCelda2);
                    ohc.setNameSpace(contenidoCelda3);
                    tablaURINSvarLocal.put(contenidoCelda1, ohc);
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(ReuseInformationGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tablaURINSvarLocal;
    }

    private OWLOntology loadOntology(/* in-out*/OntologyAnalysisResult res, String uri) {
        OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
        Callable<OWLOntology> callableObj;
        callableObj = () -> {
            IRI iri = IRI.create(uri);
            OWLOntology modeloOWL = null;
            try {
                diagnosticoTotal.setQuantityOfOntologiasQueSeHanIntentadoCargar(diagnosticoTotal.getQuantityOfOntologiasQueSeHanIntentadoCargar() + 1);
                modeloOWL = manager.loadOntologyFromOntologyDocument(iri);
            } catch (UnparsableOntologyException ex) {
                res.getDiagnosis().setCorrectParse(false);
                diagnosticoTotal.setQuantityOfUnparsableOntologyException(diagnosticoTotal.getQuantityOfUnparsableOntologyException() + 1);
                dealWithExceptions(uri, ex, res);
            } catch (OWLOntologyCreationIOException ex) {
                res.getDiagnosis().setCorrectCreationOfOntology(false);
                diagnosticoTotal.setQuantityOfOWLOntologyCreationIOException(diagnosticoTotal.getQuantityOfOWLOntologyCreationIOException() + 1);
                dealWithExceptions(uri, ex, res);
            } catch (UnloadableImportException ex) {
                res.getDiagnosis().setCorrectImportOfOntologies(false);
                res.getDiagnosis().setImportedOntologyThatHasNotBeenAbleToBeLoaded(ex.getImportsDeclaration().toString());
                diagnosticoTotal.setQuantityOfUnloadableImportException(diagnosticoTotal.getQuantityOfUnloadableImportException() + 1);
                dealWithExceptions(uri, ex, res);
            } catch (OWLOntologyAlreadyExistsException ex) {
                res.getDiagnosis().setUniqueOntology(false);
                diagnosticoTotal.setQuantityOfOWLOntologyAlreadyExistsException(diagnosticoTotal.getQuantityOfOWLOntologyAlreadyExistsException() + 1);
                dealWithExceptions(uri, ex, res);
            } catch (OWLOntologyCreationException ex) {
                res.getDiagnosis().setOntologyCorrectlyCreated(false);
                diagnosticoTotal.setQuantityOfOWLOntologyCreationException(diagnosticoTotal.getQuantityOfOWLOntologyCreationException() + 1);
                dealWithExceptions(uri, ex, res);
            } catch (Exception ex) {
                res.getDiagnosis().setOntologyWithoutGenericException(false);
                diagnosticoTotal.setQuantityOfException(diagnosticoTotal.getQuantityOfException() + 1);
                dealWithExceptions(uri, ex, res);
            }
            return modeloOWL;
        };

        // El executor sirve para crear un thread con el objeto anterior.
        ExecutorService executor = Executors.newSingleThreadExecutor();
        // En future es donde se guarda el resultado de la operación. Es
        // future porque no estará el resultado definitivo hasta que
        // la operación no termine.
        Future<OWLOntology> future = executor.submit(callableObj);
        OWLOntology modeloOWL = null;
        try {
            System.out.println("Loading of " + uri + " started..");
            try {
                //El get es bloqueante. No pasa a la siguiente línea hasta
                //que no tenga el resultado definitivo, es decir, hasta
                //que no haya terminado la ejecución del thread. El primer
                //parámetro es el timeout asignado (p.ej. 120 segundos).
                modeloOWL = future.get(OntologyDiagnosis.loadingOntologyTimeout, TimeUnit.SECONDS);
            } catch (InterruptedException | ExecutionException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("Loading of " + uri + " finished!");
        } catch (TimeoutException e) {
            future.cancel(true);
            diagnosticoTotal.setQuantityOfOntologicasConVencimientoDeTimeout(diagnosticoTotal.getQuantityOfOntologicasConVencimientoDeTimeout() + 1);
            res.getDiagnosis().setOntologyLoadingInAReasonableTime(false);
            System.err.println("Loading of " + uri + " terminated due to timeout!");
        }

        executor.shutdownNow();

        return modeloOWL;
    }

}
