/*
       Copyright 2016 Mariano Fernández-López 

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
 */
package ontologyProcessing;

import java.util.Set;

/**
 * This class is used to generate a R file with the data to be statistically
 * processed. See the file datos_reuse_generados.dat to know in detail which is
 * such an information.
 *
 * @author mariano
 */
public class RFormatter {

    /**
     * This is the method in charge of preparing the data in R format.
     * @param setOfResults the set of ontologies with their statistical data.
     * @return a string prepared to be saved as it is as a R file
     */
    public static String formatter(Set<OntologyAnalysisResult> setOfResults) {
        String cabecera = String.format("%-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %n",
                "o", "c", "op", "dp",
                "total", "ic", "iop", "idp", "ndnic", "ndnop", "ndndp");
        //StringBuilder sb = new StringBuilder("ontology\tclasses\tobject_properties\tdatatype_properties\ttotal_terms\treferred_not_declared_classes\n");
        StringBuilder sb = new StringBuilder(cabecera);
        setOfResults.forEach(resultado -> {
            sb.append(FormattedOntologyData(resultado));
        });

        return sb.toString();
    }

    private static String FormattedOntologyData(OntologyAnalysisResult resultado) {
        return String.format("%-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %n",
                resultado.getOntologyName(), resultado.getNumberOfClasses(),
                resultado.getNumberOfObjectProperties(), resultado.getNumberOfDatatypeProperties(),
                resultado.obtainTheTotalNumberOfTerms(), resultado.getNumberOfClassesFromImportedOntologies(),
                resultado.getNumberOfObjectPropertiesFromImportedOntologies(),
                resultado.getNumberOfDatatypePropertiesFromImportedOntologies(),
                resultado.getNumberOfClassesNeitherDeclaredNorFromImportedOntologies(),
                resultado.getNumberOfObjectPropertiesNeitherDeclaredNorFromImportedOntologies(),
                resultado.getNumberOfDatatypePropertiesNeitherDeclaredNorFromImportedOntologies());
    }

}
