/*
       Copyright 2016 Mariano Fernández-López 

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
 */
package ontologyProcessing;

import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import myutilities.MyUtilities;
import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;

/**
 * It is used to create statistics.
 * @author mariano
 */
public class CategoryFrequencyTableGenerator {

    final private Set<OntologyInformation> setOfOntologies = new TreeSet<>();
    final private Map<String, Integer> absoluteFrequencyTable = new HashMap<>();
    final private Map<String, Double> relativeFrequencyTable = new HashMap<>();
    final private Map<String, Long> samplingTable = new HashMap<>();
    final private String pathToFileWithTheIris = "ReuseAndTags.ods";
    final private Locale espanna = new Locale("es", "ES");
    final private NumberFormat nfPorcentaje = NumberFormat.getPercentInstance(espanna);
    final private int samplingSize = 30;
    

    /**
     * It creates a table that associates the relative frequency of each LOV category;
     * as well as a table with number of occurrences of each LOV category.
     * @param sampleSize the sample size.
     */
    public void showHowManyOntologiesWillBeSelectedBySamplingInEachCategory(int sampleSize) {
        this.nfPorcentaje.setMaximumFractionDigits(2);
        obtainReusingOntologies();
        obtainAbsoluteFrequenciesOfCategories();
        obtainCategoryRelativeFrequency();
        System.out.println("TABLA DE FRECUENCIAS RELATIVAS");
        this.relativeFrequencyTable.forEach((c, f) -> System.out.println(c + "\t" + nfPorcentaje.format(f)));
        obtainTableWithNumberOfSamplesByCategory();
        System.out.println("\nTABLA DE NÚMERO DE MUESTRAS POR CATEGORÍA");
        this.samplingTable.forEach((c, tamMuestra) -> System.out.println(c + "\t" + tamMuestra));
    }

    private void obtainCategoryRelativeFrequency() {
        double totalEltos = setOfOntologies.size();
        absoluteFrequencyTable.
                forEach((categoria, frecuenciaAbsoluta)
                        -> relativeFrequencyTable.put(categoria, frecuenciaAbsoluta / totalEltos));
    }

    private void obtainTableWithNumberOfSamplesByCategory() {
        relativeFrequencyTable.
                forEach((categoria, frecuenciaRelativa)
                        -> samplingTable.put(categoria, Math.round(frecuenciaRelativa * this.samplingSize)));
    }

    private void obtainAbsoluteFrequenciesOfCategories() {
        setOfOntologies.forEach(ontologia -> {
            absoluteFrequencyTable.putIfAbsent(ontologia.getCategory(), 0);
            absoluteFrequencyTable.put(ontologia.getCategory(),
                    absoluteFrequencyTable.get(ontologia.getCategory()) + 1);
        });
    }

    private void obtainReusingOntologies() {
        System.out.println("Importando ontologías reutilizantes a partir de hoja de cálculo");
        int filasSeguidasVacias = 0;

        try {
            File file = new File(pathToFileWithTheIris);

            //Crea un objeto para la  hoja de cálculo
            SpreadSheet hoja = SpreadSheet.createFromFile(file);
            //Toma la primera pestaña de la hoja de cálculo
            Sheet pestanna = hoja.getSheet(0);
            int numeroDeFilas = pestanna.getRowCount();

            for (int i = 1; i < numeroDeFilas && filasSeguidasVacias <= MyUtilities.getLimitOfConsecutiveEmptyRows(); i++) {
                String contenidoCelda1 = pestanna.getCellAt(0, i).getTextValue().trim();
                String contenidoCelda2 = pestanna.getCellAt(1, i).getTextValue().trim();
                //String contenidoCelda3 = pestanna.getCellAt(2, i).getTextValue().trim();
//                String contenidoCelda4 = pestanna.getCellAt(3, i).getTextValue().trim();
//                String contenidoCelda5 = pestanna.getCellAt(4, i).getTextValue().trim();
                //String contenidoCelda6 = pestanna.getCellAt(5, i).getTextValue().trim();
                boolean leyendoURI = contenidoCelda2.length() > 0;
                if (!leyendoURI) {
                    filasSeguidasVacias++;
                } else {
                    filasSeguidasVacias = 0;
                }

                if (leyendoURI) {
                    OntologyInformation reusingOntology = new OntologyInformation();
//                    OntologyInformation reusedOntology = new OntologyInformation();
                    reusingOntology.setUri(contenidoCelda1);
                    reusingOntology.setCategory(contenidoCelda2);
//                    reusedOntology.setUri(contenidoCelda4);
//                    reusedOntology.setCategory(contenidoCelda5);
//                    reusingOntology.setReusedOntology(reusedOntology);
                    setOfOntologies.add(reusingOntology);
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(ReuseInformationGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
