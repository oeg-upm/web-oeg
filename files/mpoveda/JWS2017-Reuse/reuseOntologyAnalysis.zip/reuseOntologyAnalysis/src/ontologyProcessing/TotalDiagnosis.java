/*
       Copyright 2016 Mariano Fernández-López 

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
 */
package ontologyProcessing;

/**
 * Every object of this class registers the quantity of each type of exception arisen
 * when loading all the ontologies.
 * @author mariano
 */
public class TotalDiagnosis {

    private int quantityOfUnparsableOntologyException;
    private int quantityOfOWLOntologyCreationIOException;
    private int quantityOfUnloadableImportException;
    private int quantityOfOWLOntologyAlreadyExistsException;
    private int quantityOfOWLOntologyCreationException;
    private int quantityOfException;
    private int quantityOfOntologicasConVencimientoDeTimeout;
    private int quantityOfOntologiasQueSeHanIntentadoCargar;

    /**
     * It returns the ontologies whose loading has arisen any
     * exception, without distinguishing the particular class
     * of exception.
     *
     * @return the quantity of ontologies that have provoke
     * that a exception has been arisen.
     */
    public int obtainOntologiesWithProblemsToBeLoaded() {
        return quantityOfUnparsableOntologyException
                + quantityOfOWLOntologyCreationIOException
                + quantityOfUnloadableImportException
                + quantityOfOWLOntologyAlreadyExistsException
                + quantityOfOWLOntologyCreationException
                + quantityOfException
                + quantityOfOntologicasConVencimientoDeTimeout;
    }

    /**
     * It returns how many times UnparsableOntologyException has been arisen.
     * @return how many times UnparsableOntologyException has been
     * arisen. 
     */
    public int getQuantityOfUnparsableOntologyException() {
        return quantityOfUnparsableOntologyException;
    }

    /**
     * It sets how many times UnparsableOntologyException has been arisen.
     * @param quantityOfUnparsableOntologyException how many times UnparsableOntologyException has been arisen.
     */
    public void setQuantityOfUnparsableOntologyException(int quantityOfUnparsableOntologyException) {
        this.quantityOfUnparsableOntologyException = quantityOfUnparsableOntologyException;
    }

    /**
     * It returns how many times OWLOntologyCreationIOException has been arisen.
     * @return how many times OWLOntologyCreationIOException has been arisen.
     */
    public int getQuantityOfOWLOntologyCreationIOException() {
        return quantityOfOWLOntologyCreationIOException;
    }

    /**
     * It sets how many times OWLOntologyCreationIOException has been arisen.
     * @param quantityOfOWLOntologyCreationIOException how many times OWLOntologyCreationIOException has been arisen.
     */
    public void setQuantityOfOWLOntologyCreationIOException(int quantityOfOWLOntologyCreationIOException) {
        this.quantityOfOWLOntologyCreationIOException = quantityOfOWLOntologyCreationIOException;
    }

    /**
     * It returns how many times UnloadableImportException has been arisen.
     * @return how many times UnloadableImportException has been arisen.
     */
    public int getQuantityOfUnloadableImportException() {
        return quantityOfUnloadableImportException;
    }

    /**
     * It sets how many times UnloadableImportException has been arisen.
     * @param quantityOfUnloadableImportException how many times UnloadableImportException has been arisen.
 quantityOfUnloadableImportException to set
     */
    public void setQuantityOfUnloadableImportException(int quantityOfUnloadableImportException) {
        this.quantityOfUnloadableImportException = quantityOfUnloadableImportException;
    }

    /**
     *It returns how many times OWLOntologyAlreadyExistsException has been arisen.
     * @return how many times OWLOntologyAlreadyExistsException has been arisen.
     */
    public int getQuantityOfOWLOntologyAlreadyExistsException() {
        return quantityOfOWLOntologyAlreadyExistsException;
    }

    /**
     * It sets how many times OWLOntologyAlreadyExistsException has been arisen.
     * @param quantityOfOWLOntologyAlreadyExistsException how many times OWLOntologyAlreadyExistsException has been arisen.
     */
    public void setQuantityOfOWLOntologyAlreadyExistsException(int quantityOfOWLOntologyAlreadyExistsException) {
        this.quantityOfOWLOntologyAlreadyExistsException = quantityOfOWLOntologyAlreadyExistsException;
    }

    /**
     * It returns how many times OWLOntologyCreationException has been arisen.
     * @return how many times OWLOntologyCreationException has been arisen.
     */
    public int getQuantityOfOWLOntologyCreationException() {
        return quantityOfOWLOntologyCreationException;
    }

    /**
     * It sets how many times OWLOntologyCreationException has been arisen.
     * @param quantityOfOWLOntologyCreationException how many times OWLOntologyCreationException has been arisen.
 quantityOfOWLOntologyCreationException to set
     */
    public void setQuantityOfOWLOntologyCreationException(int quantityOfOWLOntologyCreationException) {
        this.quantityOfOWLOntologyCreationException = quantityOfOWLOntologyCreationException;
    }

    /**
     * It returns how many times Exception has been arisen. 
     * @return how many times Exception has been arisen.
     */
    public int getQuantityOfException() {
        return quantityOfException;
    }

    /**
     * It sets how many times Exception has been arisen. 
     * @param quantityOfException how many times Exception has been arisen.
     */
    public void setQuantityOfException(int quantityOfException) {
        this.quantityOfException = quantityOfException;
    }

    /**
     * It returns how many times some ontology has not been loaded because
     * the timeout has expired. 
     * @return the quantityOfOntologicasConVencimientoDeTimeout
     */
    public int getQuantityOfOntologicasConVencimientoDeTimeout() {
        return quantityOfOntologicasConVencimientoDeTimeout;
    }

    /**
     * It sets how may times some ontology has not been loaded because
     * the timeout has expired.
     * @param quantityOfOntologicasConVencimientoDeTimeout the
 quantityOfOntologicasConVencimientoDeTimeout to set
     */
    public void setQuantityOfOntologicasConVencimientoDeTimeout(int quantityOfOntologicasConVencimientoDeTimeout) {
        this.quantityOfOntologicasConVencimientoDeTimeout = quantityOfOntologicasConVencimientoDeTimeout;
    }

    /**
     * How many ontologies have been tried to loaded. 
     * @return how many ontologies have been tried to be loaded. 
     */
    public int getQuantityOfOntologiasQueSeHanIntentadoCargar() {
        return quantityOfOntologiasQueSeHanIntentadoCargar;
    }

    /**
     * It sets how many ontologies have been tried to be loaded. 
     * @param quantityOfOntologiasQueSeHanIntentadoCargar how many ontologies have been tried to be loaded. 
     */
    public void setQuantityOfOntologiasQueSeHanIntentadoCargar(int quantityOfOntologiasQueSeHanIntentadoCargar) {
        this.quantityOfOntologiasQueSeHanIntentadoCargar = quantityOfOntologiasQueSeHanIntentadoCargar;
    }
}
