/*
       Copyright 2016 Mariano Fernández-López 

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
 */
package application;

import java.util.Arrays;
import ontologyProcessing.ReuseInformationGenerator;
import ontologyProcessing.CategoryFrequencyTableGenerator;

/**
 * This is the class when the program starts.
 *
 * @author mariano
 */
public class Main {

    /**
     * This method launches the methods both to generate statistics in R and the
     * report in LaTeX with the information about the process of loading
     * ontologies. It is executed in these ways:
     * <ul>
     * <li>java -jar dist/analizadorOntologias.jar -f %to generate statistics by LOV categories.</li>
     * <li>java -jar dist/analizadorOntologias.jar -i %to generate the report and the statistics for the paper.</li>
     * </ul>      *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(Arrays.toString(args));
        CategoryFrequencyTableGenerator prt = new CategoryFrequencyTableGenerator();
        if (args[0].equals("-f")) {
            prt.showHowManyOntologiesWillBeSelectedBySamplingInEachCategory(30);
        } else if (args[0].equals("-i")) {
            ReuseInformationGenerator mm = new ReuseInformationGenerator();
            mm.obtainInformationOfOntologies();
        }
//        System.out.println("áü©~ã".replaceAll("á", "\\\\'a").
//                replaceAll("ü", "\\\\\"a").replaceAll("©", "(c)").replaceAll("~", "\\\\~").
//                replaceAll("ã", "\\\\~a")
//        );
    }

}
