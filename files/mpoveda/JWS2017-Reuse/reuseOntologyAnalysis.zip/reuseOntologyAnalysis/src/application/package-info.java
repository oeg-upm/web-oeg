/**
 * Package that contains the main method where the application starts.
 */
package application;
