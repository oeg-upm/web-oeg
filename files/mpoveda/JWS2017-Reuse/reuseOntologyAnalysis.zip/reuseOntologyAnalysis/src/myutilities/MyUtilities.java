/*
       Copyright 2016 Mariano Fernández-López 

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
 */
package myutilities;

import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * It contains a list comparator and a method that returns the maximum value of
 * rows that can be in spreadsheet to be imported.
 * @author mariano
 */
public class MyUtilities {
    static final private int limitOfConsecutiveEmptyRows = 10;
    
    /**
     * Obtains the number of consecutive rows that can be empty in a
     * spreadsheet to be imported.
     * @return the limit of consequtive rows that can be empty.
     */
    public static int getLimitOfConsecutiveEmptyRows() {
        return limitOfConsecutiveEmptyRows;
    }
    
    /** It writes the content received by parameter in the specified path.
     * 
     * @param path the path where the content will be written.
     * @param content the content to be written.
     */
    static public void writeInFile(String path, String content)
    {
        try {
            FileWriter f = new FileWriter(path);
            f.write(content);
            f.close();
        } catch (IOException ex) {
            Logger.getLogger(MyUtilities.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
