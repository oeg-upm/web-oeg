/**
 * Package with general utilities useful for differente classes.
 */
package myutilities;
