cp content.tex content_anterior.tex
echo Removing lines with not latin characters
sed -i '/@ko/d' content.tex
sed -i '/@ja/d' content.tex
sed -i '/@cs/d' content.tex
sed -i '/@ru/d' content.tex
sed -i '/@el/d' content.tex
sed -i '/polishZłoty/d' content.tex
sed -i '/\^a€™/d' content.tex

echo Replacing diaeresis by \\\"
sed -i s/ä/\\\\\"a/g content.tex
sed -i s/ë/\\\\\"e/g content.tex
sed -i s/ï/\\\\\"i/g content.tex
sed -i s/ö/\\\\\"o/g content.tex
sed -i s/ü/\\\\\"u/g content.tex

sed -i s/Ä/\\\\\"A/g content.tex
sed -i s/Ë/\\\\\"E/g content.tex
sed -i s/Ï/\\\\\"I/g content.tex
sed -i s/Ö/\\\\\"O/g content.tex
sed -i s/Ü/\\\\\"U/g content.tex

echo Replacing accute accent by \\\'
sed -i s/á/\\\\\'a/g content.tex
sed -i s/é/\\\\\'e/g content.tex
sed -i s/í/\\\\\'i/g content.tex
sed -i s/ó/\\\\\'o/g content.tex
sed -i s/ú/\\\\\'u/g content.tex

sed -i s/Á/\\\\\'A/g content.tex
sed -i s/É/\\\\\'E/g content.tex
sed -i s/Í/\\\\\'I/g content.tex
sed -i s/Ó/\\\\\'O/g content.tex
sed -i s/Ú/\\\\\'U/g content.tex

echo Replacing thick accent by \\\`
sed -i s/à/\\\\\'a/g content.tex
sed -i s/è/\\\\\'e/g content.tex
sed -i s/ì/\\\\\'i/g content.tex
sed -i s/ò/\\\\\'o/g content.tex
sed -i s/ù/\\\\\'u/g content.tex

sed -i s/À/\\\\\`A/g content.tex
sed -i s/È/\\\\\`E/g content.tex
sed -i s/Ì/\\\\\`I/g content.tex
sed -i s/Ò/\\\\\`O/g content.tex
sed -i s/Ù/\\\\\`U/g content.tex

echo Replacing ß by ss
sed -i s/ß/ss/g content.tex

echo Replacing Σ by \\\Sigma
sed -i s/Σ/\\\\Sigma/g content.tex


echo Replacing ∗ by \*
sed -i s/∗/*/g content.tex

echo Replacing – by -
sed -i s/–/-/g content.tex

echo Replacing — by -
sed -i s/—/-/g content.tex

echo Removing lines with character →
sed -i '/→/d' content.tex

echo tagging imported ontologies not loaded with \\url
sed -i /OWLOntologyCreationIOException/,/http/s/http/\\\\url{http/g content.tex
