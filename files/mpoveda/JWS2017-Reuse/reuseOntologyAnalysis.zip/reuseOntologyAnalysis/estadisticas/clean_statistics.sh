set -i '/0          0          0          0          0          0          0          0          0          0/d' datos_reuse.dat 
