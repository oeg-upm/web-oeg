# INPUT: reuse_data.dat

# 1. HYPOTHESIS

# H.1. The reuse is higher in classes than in properties.
# H.2. The reuse is dependent on the size of the ontology.
# H.3. The percentage of imported terms with respect to the reused terms is dependent on the size of the ontology.
# H.3.bis The percentage of imported terms with respect to the reused terms is 0 for most of the ontologies that reuse.
# H.4. The percentage of reused ontologies across the same domain is low.
# H.5. There is series of handicaps that hampers reuse across the same domain.

# 2. DEFINION OF VARIABLES

# For each, ontology the following variables are defined:

# c: number of clases.
# p: number of properties.
# total = c + p: total number of terms.
# ic: number of imported classes.
# ip: number of imported properties.
# total_i = ic + ip: number of imported terms.
# ndnic: neither defined nor imported classes.
# ndnip: neither defined nor imported properties.
# total_ndni = ndnic + ndnip: neither defined nor imported terms.
# total_reuse = total_i + total_ndni: total number of reused terms.
# total_defined = total - total_reuse: total number of terms defined in the ontology.
# per_reuse_c = (ic + ndnic)*100/c: percentage of reused classes.  
# per_reuse_p = (ip + ndnip)*100/c: pertentage of reused properties.  
# per_reuse = total_reuse * 100 / total 
# per_i: total_i * 100 / total_reuse: pertentage of imported terms with respect to the reused terms.
# total_same: reused terms originating from ontologies of the same domain as the reusing ontology.
# total_same_w3c: terms considered in 'total_same' originating from W3C endorsed ontologies.

# 3. OBJECTIVES

# O.1. Calculate the difference between 'per_reuse_c' and 'per_reuse_p'.
# O.2. Obtain a function that relates 'per_reuse' to 'total_defined'.
# O.3. Obtain a function that relates 'per_i' to 'total_defined'.
# O.3.bis. Obtain the median of 'per_i'.
# O.4. Obtain the percentage (total_same - total_same_w3c) * 100 / total_same
# O.5. Determine if there are obtacles to reuse across the same domain. If there are, identify which.

##########################################################################################
#
# 3.1. Objective 1. Calculate the difference between 'per_reuse_c' and 'per_reuse_p'
#
# 3.1.1. R is run.

# 3.1.2. The following sentences are executed:

source("functions.R")

data <- read.table("reuse_data.dat", header = T);
data$total_i <- data$ic + data$iop + data$idp;
data$total_ndni <- data$ndnic + data$ndnop + data$ndndp;
data$total_reuse <- data$total_i + data$total_ndni;
data$total_defined_c <- data$c - data$ic - data$ndnic;
data$total_defined_op <- data$op - data$iop - data$ndnop;
data$total_defined_dp <- data$dp - data$idp - data$ndndp;
data$total_defined <- data$total - data$total_reuse;

data$per_reuse_c <- (data$ic + data$ndnic)*100/data$c;
data$per_reuse_op <- (data$iop + data$ndnop)*100/data$op;
data$per_reuse_dp <- (data$idp + data$ndndp)*100/data$dp;
data$per_reuse <- data$total_reuse * 100 / data$total;

# By means of the following sentence H.1. is validated:

jpeg('deduced_data/boxplot_per_reuse.jpg')
boxplot(data$per_reuse, data$per_reuse_c, data$per_reuse_op, data$per_reuse_dp, ylab ="reuse (%)", names=c("global", "classes", "object prop.", "data prop."))
dev.off()

##########################################################################################
#
# 3.2. Objective 2. Obtain a function that relates 'per_reuse' to 'total_defined'.
#

# The execution of the following sentences do not provide a good information due to outliers:

plot(data$total_defined, data$per_reuse)

# By means this sentence, no valuable information is obtained:
boxplot(per_reuse ~ total_defined, data=data, main="Boxplot for percentage of reuse vs the number of defined terms (both continuos vars)")

# Therefore, they are removed executing the following sentence:
data_splitted_outliers_total_defined <- split_according_to_outliers(data, "reuse_data", 'total_defined') 

# The following sentence is executed, and no relationship between 'per_reuse' and 'total_defined' is found.
plot(data_splitted_outliers_total_defined$not_outliers$total_defined, data_splitted_outliers_total_defined$not_outliers$per_reuse)

# Now, the analysis is carried out for outliers: 
plot(data_splitted_outliers_total_defined$outliers$total_defined, data_splitted_outliers_total_defined$outliers$per_reuse)


# It can be seen that the reuse in outliers is much less than in not outliers. This can be verified with the following sentence: (comment: the imported terms that are relevant in the ontology are not known)

quantiles <- quantile(data$total_defined, c(0.25, 0.5, 0.75))
threshold <- quantiles[3]+1.5*(quantiles[3]-quantiles[1])
jpeg('deduced_data/boxplot_per_reuse_splitting_according_to_outliers.jpg')
boxplot(data$per_reuse, data_splitted_outliers_total_defined$not_outliers$per_reuse, data_splitted_outliers_total_defined$outliers$per_reuse, names=c("global", paste("size <", round(threshold, 0)), paste("size > ", round(threshold, 0)-1)))
dev.off()

####################################################
# The analysis can be done for 'total', but is not significative because the reuse of big ontologies skewed the result.


data_splitted_outliers_total <- split_according_to_outliers(data, "reuse_data", 'total') 
quantiles <- quantile(data$total, c(0.25, 0.5, 0.75))
threshold <- quantiles[3]+1.5*(quantiles[3]-quantiles[1])
jpeg('deduced_data/boxplot_per_reuse_splitting_according_to_outliers.jpg')
boxplot(data$per_reuse, data_splitted_outliers_total$not_outliers$per_reuse, data_splitted_outliers_total$outliers$per_reuse, names=c("global", paste("size <", round(threshold, 0)), paste("size > ", round(threshold, 0)-1)))
dev.off()

# Consecuently, H.2 is validated:

# if total_defined < 158.75, then per_reuse is similar to the global per_reuse
# otherwise, per_reuse is lesser.

# This analysis can be extened by means the study of correlation:

cor(data$total_defined, data$per_reuse)
cor(data_splitted_outliers_total_defined$not_outliers$total_defined, data_splitted_outliers_total_defined$not_outliers$per_reuse)
cor(data_splitted_outliers_total_defined$outliers$total_defined, data_splitted_outliers_total_defined$outliers$per_reuse)

scatter.smooth(x=data_splitted_outliers_total_defined$not_outliers$total_defined, y=data_splitted_outliers_total_defined$not_outliers$per_reuse, main="% reuse ~ Total defined")  # scatterplot
scatter.smooth(x=data_splitted_outliers_total_defined$outliers$total_defined, y=data_splitted_outliers_total_defined$outliers$per_reuse, main="% reuse ~ Total defined")  # scatterplot

# No correlation is found. Therefore, the conclusion based on a threshold is a definitive conclusion for H.2.

##########################################################################################
#
# 3.3. Objective 3. Obtain a function that relates 'per_i' to 'total_defined'. 


# The population is reduced to those ontologies that reuse terms

#  a. Rows with 0% of reuse are removed (only ontologies that reuse are relevant for the sample).
#  b. The following senteces are executed so that only the data corresponding to ontologies with reuse are taken:

ontologies_that_reuse <- ontologies_that_reuse(data)

# c. Obtain per_i

total_i <- ontologies_that_reuse$ic + ontologies_that_reuse$iop + ontologies_that_reuse$idp;
total_ndni <- ontologies_that_reuse$ndnic + ontologies_that_reuse$ndnop + ontologies_that_reuse$ndndp;
total_reuse <- total_i + total_ndni;
ontologies_that_reuse$per_i <- total_i * 100 / total_reuse;

# Project the splitting of outliers of the whole population to the population of ontologies that reuse.

quantiles <- quantile(ontologies_that_reuse[,'total_defined'], c(0.25, 0.5, 0.75))
threshold <- quantiles[3]+1.5*(quantiles[3]-quantiles[1])
split_population_reuse_ontologies <- split_population(ontologies_that_reuse, "ontologies_that_reuse", 'total_defined', threshold)

# No conclusion is obtained executing the following sentence:

boxplot(ontologies_that_reuse$per_i, split_population_reuse_ontologies$down_threshold$per_i, split_population_reuse_ontologies$up_threshold$per_i)


##########################################################################################
#
# 3.3.bis. Objective 3.bis. Obtain the median of 'per_i'.

# It has been obtained in the last sentence.
# Hypothesis 3.bis is validated.


##########################################################################################
#
# 3.4. Obtain the percentage (total_same - total_same_w3c) * 100 / total_same

# 3.4.1. Data preprocessing

# INPUT: ReuseAndTags.csv, Ns_vs_Uri_congelado.csv and ontologies_that_reuse

# First of all, the ontologies that reuse ontologies belonging to same category are imported:

reuse_and_tags <- read.csv("ReuseAndTags.csv", header = TRUE, sep = ",", quote = "\"")
ns_vs_uri_congelado <- read.csv("Ns_vs_Uri_congelado.csv", header = TRUE, sep = ",", quote = "\"")
m1 <- merge(x = reuse_and_tags, y = ns_vs_uri_congelado, by.x = "vocabA_origen", by.y = "uri")
m1 <- merge(x = ontologies_that_reuse, y = m1, by = "o", select=c(o, vocabA_origen, keywordA, keywordB, vocabB_reutilizado)) # This is necessary to discard the data excluding at the beginning
m2 <- split_reuse_modules(m1)$not_mod 
m2 <- subset(m2, !grepl("Metadata", keywordA) & !grepl("RDF", keywordA) & !grepl("W3C Rec", keywordA)) # Given that there are W3C ontologies that are in domains different to W3C Rec, this subset has ontologies with the domain "w3."
ref_percentage <- dim(subset(m2, !duplicated(o)))[1] #This number includes ontologies that reuse, but excluding 'Metadata', 'RDF' and 'W3C Rec' categories. This subset is used further on as reference to calculate percentages.

write.table(subset(split_reuse_modules(m1)$mod, select = c(o, vocabA_origen, vocabB_reutilizado)), file="deduced_data/modules.dat", sep="\t", quote=FALSE) # Just for checking
write.table(subset(m1, select = c(o, vocabA_origen, vocabB_reutilizado)),  file="deduced_data/m1.dat", sep="\t", quote=FALSE) # Just for checking
write.table(subset(m2, select = c(o, vocabA_origen, vocabB_reutilizado)), file="deduced_data/not_modules.dat", sep="\t", quote=FALSE) # Just for checking
write.table(subset(m2, !duplicated(o), select=c(o, vocabA_origen, keywordA, vocabB_reutilizado, keywordB)), file="deduced_data/m2_not_repeated.dat", sep="\t", quote=FALSE) # Just for checking

# Checking ontologies assigned to several categories

dim(subset(m1, !duplicated(o)))[1]
# Result: 328

dim(subset(m1, !duplicated(c(o, keywordA))))[1]
# Result: 331
# Consequently, there are only three repetitions

# Reuse across the same domain

subset_same_domain <- subset(m2, SameDomain == 1)

subset_same_domain_not_repeated <- subset(subset_same_domain, !duplicated(o))
dim(subset_same_domain_not_repeated)[1]
per_ontologies_with_reuse_same_domain <- dim(subset_same_domain_not_repeated)[1] * 100 / ref_percentage 

write.table(subset(subset_same_domain_not_repeated, select=c(o, vocabA_origen, keywordA, vocabB_reutilizado, keywordB)), file="deduced_data/uris_reuse_not_filtered.dat", sep="\t", quote=FALSE) 
# Result: 56, 19.92883% 

# Reuse across the same domain filtered

subset_same_domain_filtered <- subset(m2, SameDomain == 1 & !grepl("w3.", vocabB_reutilizado) & !grepl("W3C Rec", keywordB) & !vocabB_reutilizado %in% ref_ontologies(), select=c(o, vocabA_origen, keywordA, keywordB, vocabB_reutilizado))

subset_same_domain_filtered_not_repeated <- subset(subset_same_domain_filtered, !duplicated(o))
dim(subset_same_domain_filtered_not_repeated)[1]
per_ontologies_with_reuse_same_domain_filtered <- dim(subset_same_domain_filtered_not_repeated)[1] * 100 / ref_percentage 

write.table(subset(subset_same_domain_filtered_not_repeated, select=c(o, vocabA_origen, vocabB_reutilizado)), file="deduced_data/uris_reuse_not_std.dat", sep="\t", quote=FALSE) 

# Given that 'per_ontologies_with_reuse_same_domain_filtered' is 12.09964 (54 ontologies), H.4 is validated. 

# Given the importance of W3C recommendations, it is important to know if W3C ontologies remain in m2:

dim(subset(m2, !grepl("Metadata", keywordA) & !grepl("RDF", keywordA) & !grepl("W3C Rec", keywordA) & grepl("w3.", vocabB_reutilizado) & !duplicated(keywordA)))[1]

#The answer is yes: 24

# More details

# Reuse of W3C ontologies across the same domain

subset_w3c_reuse <- subset(m2, SameDomain == 1 & (grepl("w3.", vocabB_reutilizado) | grepl("W3C Rec", keywordB)), select=c(o, vocabA_origen, keywordA, keywordB, vocabB_reutilizado))

subset_w3c_not_repeated <- subset(subset_w3c_reuse, !duplicated(o))
dim(subset_w3c_not_repeated)[1]
per_ontologies_w3c <- dim(subset_w3c_not_repeated)[1] * 100 / ref_percentage 

write.table(subset_w3c_not_repeated, file="deduced_data/w3c_not_repeated.dat", sep="\t", quote=FALSE)
#Result: 13, 4.626335% 

# Reuse of ref. ontologies across the same domain

subset_ref_ontologies <- subset(m2, SameDomain == 1 & vocabB_reutilizado %in% ref_ontologies(), select=c(o, vocabA_origen, keywordA, keywordB, vocabB_reutilizado))

subset_ref_ontologies_not_repeated <- subset(subset_ref_ontologies, !duplicated(o))
dim(subset_ref_ontologies_not_repeated)[1] 
per_ref_ontologies <- dim(subset_ref_ontologies_not_repeated)[1] * 100 / ref_percentage

write.table(subset_ref_ontologies_not_repeated, "deduced_data/ref_ontologies.dat", sep="\t", quote=FALSE)
#Result: 15, 3.558719% 

# Reuse of de iure or de facto standards across the same domain

subset_standards <- subset(m2, SameDomain == 1 & (grepl("w3.", vocabB_reutilizado) | grepl("W3C Rec", keywordB) | vocabB_reutilizado %in% ref_ontologies()), select=c(o, vocabA_origen, keywordA, keywordB, vocabB_reutilizado))

subset_standards_not_repeated <- subset(subset_standards, !duplicated(o))
dim(subset_standards_not_repeated)[1]
per_standards <- dim(subset_standards_not_repeated)[1] * 100 / ref_percentage

write.table(subset_standards_not_repeated, "deduced_data/standards.dat", sep="\t", quote=FALSE)
#Result: 27, 9.608541%

# Reuse of the iure or de facto standards without constraints

dim(subset(m1, (grepl("w3.", vocabB_reutilizado) | grepl("W3C Rec", keywordB) | vocabB_reutilizado %in% ref_ontologies()) & !duplicated(o)))[1]
# Result: 277

dim(subset(m1, (grepl("w3.", vocabB_reutilizado) | grepl("W3C Rec", keywordB) | vocabB_reutilizado %in% ref_ontologies()) & !duplicated(o)))[1] * 100 / dim(data)[1]
# Result: 78.02817

# Modularization

m3 <- split_reuse_modules(m1)$mod 
subset_modularization <- subset(m3, SameDomain == 1)

subset_modularization_not_repeated <- subset(subset_modularization, !duplicated(o))
dim(subset_modularization_not_repeated)[1]

write.table(subset_modularization_not_repeated, file="deduced_data/modularization.dat", sep="\t", quote=FALSE)
#Result: 59 

# STUDY OF W3C ONTOLOGIES FOR REUSE ACROSS THE SAME DOMAIN

subset_w3c <- subset(m1, grepl("w3.", vocabA_origen) | grepl("W3C Rec", keywordA))
write.table(subset_w3c, file="deduced_data/subset_w3c.dat", sep="\t", quote=FALSE)
subset_w3c_not_repeated <- subset(subset_w3c, !duplicated(o))
per_ref_w3c <- dim(subset_w3c_not_repeated)[1] # This number is the denominator in the following percentages.
write.table(subset(subset_w3c_not_repeated, select=c(o, vocabA_origen, vocabB_reutilizado)), "deduced_data/w3c_ontologies.dat", sep="\t", quote=FALSE) 
#per_ref_w3c = 37

# W3C ontologies that reuse other ontologies of the same domain

subset_w3c_same_domain <- subset(subset_w3c, SameDomain == 1 & !duplicated(o), select=c(o, vocabA_origen, keywordA, vocabB_reutilizado, keywordB))
dim(subset_w3c_same_domain)[1]
per_w3c_same_domain <- dim(subset_w3c_same_domain)[1] * 100 / per_ref_w3c
write.table(subset_w3c_same_domain, "deduced_data/w3c_same_domain.dat", sep="\t", quote=FALSE) 
# Consulting the file, it can be seen that the solely domain is 'W3C Rec'

# Result: 6, 16.21622%

# W3C ontologies that reuse other W3C ontologies

subset_w3c_w3c <- subset(subset_w3c, grepl("w3.", vocabB_reutilizado) & !duplicated(o), select=c(o, vocabA_origen, vocabB_reutilizado))
dim(subset_w3c_w3c)[1]
per_w3c_w3c <- dim(subset_w3c_w3c)[1] * 100 / per_ref_w3c
write.table(subset(subset_w3c_w3c, select=c(o, vocabA_origen, vocabB_reutilizado)), "deduced_data/w3c_w3c.dat", sep="\t", quote=FALSE) 
# Result: 26, 70.27027%

# W3C ontologies that reuse ref. ontologies

subset_w3c_ref <- subset(subset_w3c, !grepl("w3.", vocabB_reutilizado) & !vocabB_reutilizado %in% ref_ontologies() & !duplicated(o))
dim(subset_w3c_ref)[1]
per_w3c_ref <- dim(subset_w3c_ref)[1] * 100 / per_ref_w3c
write.table(subset(subset_w3c_ref, select=c(o, vocabA_origen, vocabB_reutilizado)), "deduced_data/w3c_ref.dat", sep="\t", quote=FALSE) 
# Result: 1, 2.702703%

# Reuse of not standard ontologies

subset_w3c_not_std <- subset(subset_w3c, !grepl("w3.", vocabB_reutilizado) & !vocabB_reutilizado %in% ref_ontologies() & !duplicated(o))
dim(subset_w3c_not_std)[1]
per_w3c_not_std <- dim(subset_w3c_not_std)[1] * 100 / per_ref_w3c
write.table(subset(subset_w3c_not_std, select=c(o, vocabA_origen, vocabB_reutilizado)), "deduced_data/w3c_not_std.dat", sep="\t", quote=FALSE) 
# Result: 1, 2.702703%

##########################################################################################
#
# 3.5. Objective 5. Determine if there are obtacles to reuse across the same domain. If there are, identify which.

uris <- read.csv("uris.csv", header = TRUE, sep = ",", quote = "\"")
ma1 <- merge(x = data, y = uris, by.x = "o", by.y = "prefix", select=c(namespace, uri)) #Lets note that the original set 'data' is taken
write.table(subset(ma1, select=uri), "deduced_data/uris_ontologies.dat", sep="\t", quote=FALSE)


# The number of languages used in LOV ontologies is calculated:

languages <- read.csv("languages.csv", header = TRUE, sep = ",", quote = "\"")

dim(subset(languages, !duplicated(l)))[1]

#Result: 48 languages

# Now, the number of ontologies that use some language different to English is calculated:

# English is removed before calculated the number of ontolologies that use other languages different to Spanish:
no_en <- subset(languages, l != "http://id.loc.gov/vocabulary/iso639-2/eng")
dim(subset(no_en, !duplicated(np)))[1]
#Result: 96 ontologies

# Now, the percentage of ontologies that use some language different to English is calculated:

dim(subset(no_en, !duplicated(np)))[1] * 100 / dim(data)[1]
#Resutl: 27.04225

#Licenses
#(355, 214, 60.28169014084507)

#HTML pages
#(355, 61, 17.183098591549296)
