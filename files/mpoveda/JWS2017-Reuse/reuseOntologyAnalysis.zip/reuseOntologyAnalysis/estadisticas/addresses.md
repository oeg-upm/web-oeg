1. Languages:

<http://ontoreuse.linkeddata.es/sparql?default-graph-uri=&query=select+distinct+%3Fv+%3Fnp+%3Fl%0D%0A%0D%0A%0D%0A+where+%7B%0D%0A%0D%0A%3Fv+a+%3Chttp%3A%2F%2Fpurl.org%2Fvocommons%2Fvoaf%23Vocabulary%3E+.%0D%0A%3Fv+%3Chttp%3A%2F%2Fpurl.org%2Fvocab%2Fvann%2FpreferredNamespacePrefix%3E+%3Fnp+.%0D%0A%0D%0A%3Fv+%3Chttp%3A%2F%2Fpurl.org%2Fdc%2Fterms%2Flanguage%3E+%3Fl%0D%0A%7D%0D%0A&format=text%2Fhtml&timeout=0&debug=on>

2. URI

<http://ontoreuse.linkeddata.es/sparql?default-graph-uri=&query=select+distinct+%3Furi+%3Fprefix+%3Fnamespace%0D%0A%0D%0A%0D%0A+where+%7B%0D%0A%0D%0A%3Furi+a+%3Chttp%3A%2F%2Fpurl.org%2Fvocommons%2Fvoaf%23Vocabulary%3E+.%0D%0A%3Furi+%3Chttp%3A%2F%2Fpurl.org%2Fvocab%2Fvann%2FpreferredNamespacePrefix%3E+%3Fprefix+.%0D%0A%3Furi+%3Chttp%3A%2F%2Fpurl.org%2Fvocab%2Fvann%2FpreferredNamespaceUri%3E+%3Fnamespace+.%0D%0A%0D%0A%7D+order+by+%3Fprefix&format=text%2Fhtml&timeout=0&debug=on>
