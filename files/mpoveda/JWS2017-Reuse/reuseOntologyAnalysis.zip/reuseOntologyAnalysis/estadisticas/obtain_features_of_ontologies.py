from rdflib.graph import Graph
from langdetect import detect
from rdflib.plugin import PluginException
from rdflib.util import guess_format
from rdflib.exceptions import ParserError
from langdetect.lang_detect_exception import LangDetectException
import requests

def obtain_licenses():
	return obtain_feature_of_each_ontology(obtain_license)

def obtain_languages():
	return obtain_feature_of_each_ontology(obtain_language)

def obtain_htmls():
	return obtain_feature_of_each_ontology(obtain_html)

def obtain_feature_of_each_ontology(function):
	f = open('uris_ontologies.dat', 'r')
	read_data = f.read()	
	f.close()
	uris = read_data.split('\n')
	result_list = []
	for uri in uris[1:-1]:
		result_list.append(function(uri.split("   ")[0].split("\t")[1]))
	print(result_list)
	total_number_of_ontologies = len(list(filter(lambda x: x != 'exception', result_list)))
	number_of_hit_ontologies = len(list(filter(lambda x: x != set() and x != 'exception', result_list)))
	return (total_number_of_ontologies, number_of_hit_ontologies, number_of_hit_ontologies *100 / total_number_of_ontologies)	

def load_ontology(uri):
	g = Graph()
	print("Processing ontology ", uri)
	exception = False
	try:
		g.parse(uri, format=guess_format(uri))
	except (PluginException, ParserError, ImportError, Exception):
		exception = True
	return g, exception

def obtain_language(uri):
	g = load_ontology(uri)
	qres = g[0].query(
		"""PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
		   SELECT DISTINCT ?x ?y WHERE 
		   {
		      ?x rdfs:comment ?y .
		   }""")
	set_of_languages = set() 
	if (g[1]): set_of_languages.add('exception')
	for row in qres:
		try:	
			set_of_languages.add(detect(row.y))
		except LangDetectException:
			print("The ontology ", uri, " has provoked a language detection error\n")
	print(set_of_languages)
	return set_of_languages

def obtain_license(uri):
	g = load_ontology(uri)
	qres = g[0].query(
		""" PREFIX dct:     <http://purl.org/dc/terms/> 
		    PREFIX dc:      <http://purl.org/dc/elements/1.1/>
		    PREFIX dcterms: <http://purl.org/dc/terms/>
		    PREFIX cc:      <http://creativecommons.org/ns#> 
		    PREFIX xhv:     <http://www.w3.org/1999/xhtml/vocab#>

		    SELECT ?license WHERE {
		    { ?c dct:license ?license . } UNION 
		    { ?c dc:rights ?license .} UNION 
		    { ?c dcterms:rights ?license .} UNION
	            { ?c dcterms:license ?license .} UNION 
		    { ?c cc:license ?license .} UNION
		    { ?c xhv:license ?license .} }""")
	set_of_licenses = set() 
	if (g[1]): set_of_licenses.add('exception')
	for row in qres:
		print(row.license)	
		set_of_licenses.add(row.license)
	return set_of_licenses

def obtain_html(uri):
	set_of_htmls = set()
	try:
		headers = {'Accept': 'text/html',}
		response = requests.get(uri, headers=headers)
		if (response.headers['content-type']=='text/html'): set_of_htmls.add(uri)
	except Exception:
		print("An exception has raised when accessing to uri ", uri)
	return set_of_htmls
