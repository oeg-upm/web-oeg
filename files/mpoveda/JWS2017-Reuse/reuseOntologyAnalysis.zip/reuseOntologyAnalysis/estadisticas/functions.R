# Input: 'file_with_data', which is the file that contains the data generated from LOV using the Java tool, and filtered with 'clean_statistics.sh'
# Output: a table with the LOV ontologies that reuse. The result is stored in a file (just for trace purposes).
# Process: for each data, if its 'per_reuse' is different from 0, is selected for the output.

ontologies_that_reuse <- function(data)
{
    ontologies_that_reuse <- subset(data, per_reuse != 0)

    write.table(ontologies_that_reuse, file="deduced_data/ontologies_that_reuse.dat", sep="\t", quote=FALSE); #quote=FALSE so that quotations are not used in not numerical values.

    return(ontologies_that_reuse)
}

# Input: 'table' with the data, 'label' of the table, and the 'attribute_number'
# Output: a table without the outliers with respect to the 'attribute_number'. The formula used is LS = Q3 + 1.5 * (Q3 - Q1).
# The data are stored (just for trace purposes) in a file whose name consists of the label of the table, the name of the attribute, the string "greater_than", the threshold (LS) and the extension '.dat'.

split_according_to_outliers <- function(table, label, attribute_number)
{
    quantiles <- quantile(table[,attribute_number], c(0.25, 0.5, 0.75))
    threshold <- quantiles[3]+1.5*(quantiles[3]-quantiles[1])
    print(threshold)
    #Only the case of Q3 + 1.5 * (Q3 - Q1) is interested because the case with the
    #substraction works out less than 0.
    vector_1 <- NULL
    vector_2 <- NULL
    for(i in 1:dim(table)[1])
    {
        if (table[i,attribute_number] <= threshold)
        {
            vector_1 <- c(vector_1, i)
        }else {
            vector_2 <- c(vector_2, i)
        }
    } 
    write.table(table[vector_1,], file=paste("deduced_data/", label, "_without_outliers_with_respect_to_", colnames(table)[attribute_number], ".dat", sep=""), sep="\t", quote=FALSE); #quote=FALSE so that quotations are not used in not numerical values.
    write.table(table[vector_2,], file=paste("deduced_data/", label, "_outliers_with_respect_to_", colnames(table)[attribute_number], ".dat", sep=""), sep="\t", quote=FALSE); 
    
    return(list("not_outliers" = table[vector_1,], "outliers" = table[vector_2,]))
}

split_population <- function(table, label, attribute_number, threshold)
{
    vector_1 <- NULL
    vector_2 <- NULL
    for(i in 1:dim(table)[1])
    {
        if (table[i,attribute_number] <= threshold)
        {
            vector_1 <- c(vector_1, i)
        }else{vector_2 <- c(vector_2, i)}
    }
    write.table(table[vector_1,], file=paste("deduced_data/", label, "_down_threshold_", colnames(table)[attribute_number], "_", threshold, ".dat", sep=""), sep="\t", quote=FALSE); #quote=FALSE so that quotations are not used in not numerical values.
    write.table(table[vector_2,], file=paste("deduced_data/", label, "_up_threshold_", colnames(table)[attribute_number],  "_", threshold, ".dat", sep=""), sep="\t", quote=FALSE); #quote=FALSE so that quotations are not used in not numerical values.
    return(list("down_threshold" = table[vector_1,], "up_threshold" = table[vector_2,]))
}

good_ontologies <- function()
{
    c("http://purl.org/dc/terms/", "http://purl.org/dc/elements/1.1/", "http://xmlns.com/foaf/0.1/", "http://rdfs.org/sioc/ns#", "http://purl.org/goodrelations/v1", "http://purl.org/ontology/mo/", "http://ics.forth.gr/MarineTLO/icore#", "http://ics.forth.gr/MarineTLO/imarine#") 
}

ref_ontologies <- function()
{
    c(good_ontologies(), "http://schema.org/", "http://www.geonames.org/ontology")
    # Geonames is referred in https://www.w3.org/2005/Incubator/geo/XGR-geo-ont-20071023/
}

is_module <- function(uri_1, uri_2)
{
    is_purl <- grepl("http://purl.org", uri_1) & grepl("http://purl.org", uri_2)
    if (is_purl) return (grepl(unlist(strsplit(toString(uri_1), split = "/"))[4], unlist(strsplit(toString(uri_2), split = "/"))[4]))
    else 
    { 
        strs_dom_web_1 <- unlist(strsplit(unlist(strsplit(toString(uri_1), split = "/"))[3], split="\\."))
        strs_dom_web_2 <- unlist(strsplit(unlist(strsplit(toString(uri_2), split = "/"))[3], split="\\."))
        return(length(strs_dom_web_1) == length(strs_dom_web_2) & all(strs_dom_web_1 == strs_dom_web_2))
    }
}

split_reuse_modules <- function(data)
{
    vector_mod <- NULL
    vector_not_mod <- NULL
    for(i in 1:dim(data)[1])
    {
        if (!is_module(data[i,]$vocabA_origen, data[i,]$vocabB_reutilizado))
        {
            vector_not_mod <- c(vector_not_mod, i)
        }else
        {
            vector_mod <- c(vector_mod, i)
        }
    }
    return (list("not_mod"=data[vector_not_mod,], "mod"=data[vector_mod,])) 
}
